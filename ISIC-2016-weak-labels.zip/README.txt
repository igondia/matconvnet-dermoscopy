==================================
ISIC 2016 weak segmentation labels
==================================

Each image in ISIC2016 dataset has an associated annotation file .ann which contains the weak labels for the considered structures. The annotation vector has 9 elements with the weak label associated to the following dermoscopic structures: 
(1) Cobblestone pattern (G) - globular pattern (G) - Globules (L)
(2) homogeneous pattern (G) - starburst pattern (G)
(3) reticular pattern (G) - PigmentNetwork (L)
(4) Streaks (L) 
(5) BlueWVeil (L)
(6) VascularStr (L)
(7) Hypopigmentation (L)
(8) RegressionStr (L)
(9) unspecific pattern (G)

In addition, each element can have 3 different values: 
0 - the structure is not present
1 - the structure is locally present in the lesion
2 - the structure is present and becomes the main global pattern in the lesion
